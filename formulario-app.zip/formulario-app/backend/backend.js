const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 9999;

app.use(cors());
app.use(bodyParser.json());

app.post('/submit', (req, res) => {
    const { nombre, correo, mensaje } = req.body;
    
    console.log("Datos recibidos:");
    console.log(`Nombre: ${nombre}`);
    console.log(`Correo: ${correo}`);
    console.log(`Mensaje: ${mensaje}`);


    res.json({ message: 'Datos recibidos correctamente' });
});

app.listen(port, () => {
    console.log(`Servidor Back-End escuchando en http://localhost:${port}`);
});
