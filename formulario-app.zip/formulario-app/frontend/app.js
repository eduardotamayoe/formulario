document.getElementById('userForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const nombre = document.getElementById('nombre').value;
    const correo = document.getElementById('correo').value;
    const mensaje = document.getElementById('mensaje').value;

    fetch('http://localhost:9999/submit', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            nombre: nombre,
            correo: correo,
            mensaje: mensaje
        })
    })
    .then(response => response.json())
    .then(data => {
        alert("Formulario enviado exitosamente");
        console.log(data);
    })
    .catch(error => {
        alert("Hubo un error al enviar el formulario");
        console.error(error);
    });
});
